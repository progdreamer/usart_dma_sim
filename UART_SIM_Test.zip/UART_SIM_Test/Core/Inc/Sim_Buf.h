/*
 * Sim_Buf.h
 *
 *  Created on: Apr 12, 2023
 *      Author: Simple
 */

#ifndef SRC_SIM_BUF_H_
#define SRC_SIM_BUF_H_

void Ringbuf_Init (void);

uint8_t isConfirmed (int32_t Timeout);



#endif /* SRC_SIM_BUF_H_ */
