
#ifndef SRC_SIM_BUF_H_
#define SRC_SIM_BUF_H_

void Ringbuf_Init (void);

int waitFor (char *string, uint32_t Timeout);

void Ringbuf_Reset (void);

uint8_t isConfirmed (int32_t Timeout);

void getinfo1(void);

void getinfo2(void);


#endif /* SRC_SIM_BUF_H_ */
