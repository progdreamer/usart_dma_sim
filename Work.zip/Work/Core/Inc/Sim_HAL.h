

#ifndef INC_SIM_HAL_H_
#define INC_SIM_HAL_H_

int Sim_Init (int point);
int Sim_Init2 (int point2);
void getinfognss(void);

#endif /* INC_SIM_HAL_H_ */
