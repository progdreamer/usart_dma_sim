#include "stm32f4xx_hal.h"
#include "Sim_Buf.h"
#include "string.h"

extern UART_HandleTypeDef huart2;
extern DMA_HandleTypeDef hdma_usart2_rx;
extern UART_HandleTypeDef huart6;


#define BufSIZE 512
#define MainBufSIZE 1024
uint8_t RxBuf[BufSIZE];
uint8_t MainBuf[MainBufSIZE];
uint16_t oldData = 0;
uint16_t newPos = 0;
uint16_t Head, Tail;
int isDataAvailable = 0;
int isOK = 0;
int32_t TIMEOUT = 0;
char longitudebuf[11];
char latitudebuf[10];
char* longitude(const char *infch1)
{
 memcpy(longitudebuf, &infch1[42], 10);
 return longitudebuf;
}
char* latitude(const char *infch2)
{
 memcpy(latitudebuf, &infch2[32], 9);
 return latitudebuf;
}
void Ringbuf_Init (void)
{
memset(RxBuf, '\0', BufSIZE);
memset(MainBuf, '\0', MainBufSIZE);
Head = Tail = 0;
oldData = 0;
newPos = 0;
HAL_UARTEx_ReceiveToIdle_DMA(&huart2, RxBuf, BufSIZE);
__HAL_DMA_DISABLE_IT(&hdma_usart2_rx, DMA_IT_HT);
}
uint8_t isConfirmed (int32_t Timeout)
{
	TIMEOUT = Timeout;
	while ((!isOK)&&(TIMEOUT>0));
	isOK = 0;
	if (TIMEOUT <= 0) return 0;
//	isOK = 0;
	return 1;
}

void Ringbuf_Reset (void)
{
	memset(MainBuf,'\0', MainBufSIZE);
	memset(RxBuf, '\0', BufSIZE);
	Tail = 0;
	Head = 0;
	oldData = 0;
	newPos = 0;
	isOK = 0;
}
int waitFor(char *string, uint32_t Timeout)
{
	isDataAvailable = 0;
	int so_far =0;
	int len = strlen (string);
	TIMEOUT = Timeout;
do {
    if (isDataAvailable)
{
         do { if (MainBuf[Tail] == string[so_far])
{
                    so_far++;
                    if (so_far == len) {
                        return 1;
                    }
              } else {
		so_far= 0;
                }
                Tail= (Tail + 1) % MainBufSIZE;
            } while (so_far != len);
        }
        isDataAvailable = (Head != Tail);
        HAL_Delay (100);
        if (!isDataAvailable && (0 >= TIMEOUT)) {
            return 0;
        }
    } while (1);
}
void getinfo1(void)
{
// char *buff = MainBuf;
// char* dest1[11]=longitude(MainBuf);
// char* dest2[10]=latitude(MainBuf);
 HAL_UART_Transmit_DMA(&huart6, (uint8_t *)  longitude(MainBuf),strlen (longitude(MainBuf)));
}
void getinfo2(void)
{
	HAL_UART_Transmit_DMA(&huart6, (uint8_t *)  latitude(MainBuf),strlen (latitude(MainBuf)));
}

//void INFGNC (char info){

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
	//void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
	{
		if (huart->Instance == USART1)
		{
			isDataAvailable = 1;
			oldData = newPos;
			if (oldData+Size > MainBufSIZE)
			{
				uint16_t datatocopy = MainBufSIZE-oldData;
				memcpy ((uint8_t *)MainBuf+oldData, (uint8_t *)RxBuf, datatocopy);
				oldData = 0;
				memcpy ((uint8_t *)MainBuf, (uint8_t *)RxBuf+datatocopy, (Size-datatocopy));
				newPos = (Size-datatocopy);
			}
			else
			{
			memcpy ((uint8_t *)MainBuf+oldData, (uint8_t *)RxBuf, Size);
			newPos = Size+oldData;
			}
			if (Head+Size < MainBufSIZE) Head = Head+Size;
			else Head = Head+Size - MainBufSIZE;
			for (int i=0; i<=BufSIZE; i++)
				{
					if ((RxBuf[i] == 'O') && (RxBuf[i+1] == 'K'))
					{
						isOK = 1;
					}
			}
			HAL_UART_Transmit_DMA(&huart6, RxBuf, Size);
			HAL_UARTEx_ReceiveToIdle_DMA(&huart2, RxBuf, BufSIZE);
			__HAL_DMA_DISABLE_IT(&hdma_usart2_rx, DMA_IT_HT);
		}

	}
