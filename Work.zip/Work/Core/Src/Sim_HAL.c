#include "stm32f4xx_hal.h"
#include "Sim_Buf.h"
#include "Sim_HAL.h"
#include "stdio.h"
#include "string.h"

extern UART_HandleTypeDef huart2;
extern DMA_HandleTypeDef hdma_usart2_rx;
extern UART_HandleTypeDef huart6;
//char buffer[200];

//extern int32_t TIMEOUT;
static void uartSend (char *str)
{
	HAL_UART_Transmit_DMA(&huart2, (uint8_t *) str,strlen (str));
}

static void debugLog (char *str)
{
	HAL_UART_Transmit_DMA(&huart6, (uint8_t *) str,strlen (str));
}
/**********************************************/

int Sim_Init (int point)
{
	Ringbuf_Init();
uartSend("AT");
	if(isConfirmed(50000) != 1)
	{
		debugLog("Error\r\n");
		return 0;
	}
	HAL_Delay (100);
	debugLog("\nAT---->OK\r\n");
//	TIMEOUT = 0;
//	Ringbuf_Reset();
//	HAL_UART_DMAStop(sim_uart);
//	TIMEOUT = 0;
	HAL_Delay (1000);
	uartSend("AT+CPIN?");
	if(isConfirmed(50000) != 1)
	{
		debugLog("Error\r\n");
		return 0;
	}
	HAL_Delay (100);
	debugLog("\nAT---->CPINOK\r\n");
//	HAL_UART_DMAStop(sim_uart);
//	Ringbuf_Reset();
	HAL_Delay (1000);
uartSend("AT+CNMP=38\r\n");
	if(isConfirmed(5000) != 1)
	{
		debugLog("Error\n");
		return 0;
	}
	HAL_Delay (100);
	debugLog("\nAT---->CNMPOK\n\n");
////	HAL_DMA_Stop(sim_uart);
//	Ringbuf_Reset();
	HAL_Delay (1000);
uartSend("AT+CMNB=2\r\n");
	if(isConfirmed(5000) != 1)
	{
		debugLog("Error\n");
		return 0;
	}
	HAL_Delay (100);
	debugLog("\nAT---->AT+CMNBOK\n\n");
//	Ringbuf_Reset();
////	HAL_DMA_Stop(sim_uart);
	HAL_Delay (1000);
uartSend("AT+CSQ\r\n");
	if(isConfirmed(5000) != 1)
	{
		debugLog("Error\r\n");
		return 0;
	}
	HAL_Delay (100);
	debugLog("\nAT---->CSQOK\r\n");
//	Ringbuf_Reset();
//	HAL_DMA_Stop(sim_uart);
	HAL_Delay (1000);
uartSend("AT+CGREG?\r\n");
	if(isConfirmed(5000) != 1)
	{
		debugLog("failed\r\n");
		return 0;
	}
	HAL_Delay (100);
	debugLog("\nAT---->CGREGOK\r\n");
//	Ringbuf_Reset();
////	HAL_DMA_Stop(sim_uart);
	HAL_Delay (1000);
uartSend("AT+CGNAPN\r\n");
	if(isConfirmed(10000) != 1)
	{
		debugLog("Error\n");
		return 0;
	}
	HAL_Delay (100);
	debugLog("\nAT---->CGNAPN\n\n");
	Ringbuf_Reset();
//	HAL_DMA_Stop(sim_uart);
	HAL_Delay (1000);
//	HAL_Delay (1000);
uartSend("AT+CNACT=0,1\r\n");
	if(waitFor("OK", 10000) != 1)
	{
		debugLog("Error\n");
		return 0;
	}
	HAL_Delay (100);
	debugLog("\nAT---->CNACT\n\n");
	Ringbuf_Reset();
//	HAL_DMA_Stop(sim_uart);
	HAL_Delay (1000);
uartSend("AT+CLTS=1\r\n");
	if(waitFor("OK", 80000) != 1)
	{
		debugLog("Error\n");
		return 0;
	}
	HAL_Delay (100);
	debugLog("\nAT---->CLTS\n\n");
	Ringbuf_Reset();
////	HAL_DMA_Stop(sim_uart);
	HAL_Delay (1000);
uartSend("AT+HTTPTOFS=\"http://iot2.xtracloud.net/xtra3gr_72h.bin\",\"/customer/Xtra3.bin\"\r\n");
//	debugLog("\nAT---->CLTS\n\n");
	if(waitFor("HTTPTOFS", 1000000) != 1)
	{
		debugLog("Ok\n");
		return 0;
	}
	HAL_Delay (100);
	debugLog("\nAT---->HTTPTOFS\n\n");
	Ringbuf_Reset();
	HAL_Delay (1000);
uartSend("AT+CGNSCPY\r\n");
	if(waitFor("+CGNSCPY: 0", 100000) != 1)
	{
		debugLog("Error\n");
		return 0;
	}
	HAL_Delay (100);
	debugLog("\nAT---->CGNSCPY\n\n");
	Ringbuf_Reset();
////	HAL_DMA_Stop(sim_uart);
	HAL_Delay (1000);
uartSend("AT+CGNSXTRA\r\n");
	if(waitFor("OK", 100000) != 1)
	{
		debugLog("Error\n");
		return 0;
	}
	HAL_Delay (100);
	debugLog("\nAT---->CGNSXTRA\n\n");
	Ringbuf_Reset();
////	HAL_DMA_Stop(sim_uart);
	HAL_Delay (1000);
uartSend("AT+CGNSXTRA=1\r\n");
	if(waitFor("OK", 80000) != 1)
	{
		debugLog("Error\n");
		return 0;
	}
	HAL_Delay (100);
	debugLog("\nAT---->CGNSXTRA\n\n");
	Ringbuf_Reset();
//
////	HAL_DMA_Stop(sim_uart);
	HAL_Delay (1000);
uartSend("AT+CGNSPWR=1\r\n");
	if(isConfirmed(5000) != 1)
	{
		debugLog("Error\n");
		return 0;
	}
	HAL_Delay (100);
	debugLog("\nAT---->CGNSCOLD\n\n");
	Ringbuf_Reset();
	HAL_Delay(1000);
	uartSend("AT+CGNSCOLD\r\n");
	if (isConfirmed(5000) != 1) {
		debugLog("Error\n");
		return 0;
	}
	HAL_Delay (100);
	debugLog("\nAT---->CGNSCOLD\n\n");
//	uartSend("AT+CGNSINF\r\n");
//	if (waitFor("+CGNSINF:", 10000) != 1) {
//		debugLog("Error\n");
//		return 0;
//	}
//	debugLog("\nAT---->INF\n\n");
//	HAL_Delay (10000);
	Ringbuf_Reset();
	HAL_Delay (1000);
	return 1;
}
void getinfognss(void)
{
	uartSend("AT+CGNSINF\r\n");
	if (waitFor("+CGNSINF:", 10000) != 1) {
	debugLog("Error\n");
	}
	getinfo1();
	HAL_Delay (1000);
	getinfo2();
	HAL_Delay (2000);
	Ringbuf_Reset();
}
